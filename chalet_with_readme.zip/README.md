# 🏡 Mini Chalet 3D

Ce dépôt contient une page web interactive affichant un **mini chalet moderne en 3D**.

## 🚀 Comment accéder au chalet en ligne

1. Ouvrez ce dépôt sur GitHub.  
2. Allez dans **Settings → Pages**.  
3. Sous **Source**, choisissez :  
   - Branch : `main`  
   - Folder : `/root`  
4. Cliquez sur **Save**.  
5. Après 1–2 minutes, votre chalet sera en ligne à l'adresse :  

```
https://VOTRE_PSEUDO.github.io/chalet/
```

*(remplacez `VOTRE_PSEUDO` par votre identifiant GitHub)*

## 🖱️ Contrôles de la vue 3D

- **Glisser avec un doigt / la souris** : rotation autour du chalet  
- **Pincer / molette** : zoom avant-arrière  
- **Glisser à deux doigts** : déplacement de la caméra  

## 💾 Télécharger le modèle 3D

Un bouton **Télécharger .glb** en haut à gauche de la page vous permet de récupérer le modèle.

---

Créé avec ❤️ et [Three.js](https://threejs.org/)
